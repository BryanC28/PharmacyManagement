package model;

public enum StatusType {
    PENDING, APPROVED, REJECT
}