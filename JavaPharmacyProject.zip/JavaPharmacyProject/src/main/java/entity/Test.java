package entity;

import java.sql.Connection;
import common.ConnectDB;

public class Test {

	public static void main(String[] args) {
		try (Connection con = ConnectDB.getConnect())
		{
			System.out.println("Success");
		} catch (Exception e) {
			e.printStackTrace();
		}
		

	}

}
