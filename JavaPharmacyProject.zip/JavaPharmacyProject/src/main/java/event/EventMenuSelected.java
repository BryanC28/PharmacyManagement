package event;

public interface EventMenuSelected {

    public void selected(int index);
}
