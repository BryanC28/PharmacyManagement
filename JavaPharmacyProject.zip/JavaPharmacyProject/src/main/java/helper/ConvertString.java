package helper;

public class ConvertString {
	public static String namePicture(String value) {
		   int index = value.lastIndexOf('\\') + 1;
		   String newStr = value.substring(index);
		return newStr;
	}
	
	public static void main(String[] args) {
		String str = namePicture("src\\main\\resources\\Image\\123456678.png");
		System.out.println(str);
	}
}
